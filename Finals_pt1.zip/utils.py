import numpy as np

def onehotCategorical(req, limit, zip=0):
    arr = np.zeros((limit,))
    arr[req] = 1.
    #if store == 1: # encode Store
    #    arr = np.delete(arr, [290, 621, 878])
    return arr


def switch_month(month):
    switcher = {
        "Jan": 1.0,
        "Feb": 2.0,
        "Mar": 3.0,
        "Apr": 4.0,
        "May": 5.0,
        "Jun": 6.0,
        "Jul": 7.0,
        "Aug": 8.0,
        "Sep": 9.0,
        "Oct": 10.0,
        "Nov": 11.0,
        "Dec": 12.0
    }
    return switcher.get(month)



