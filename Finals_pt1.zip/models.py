# REFERENCES:
# Class lectures, labs and homeworks
# https://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-viii-followers
# https://docs.sqlalchemy.org/en/latest/core/metadata.html#accessing-tables-and-columns

# import SQLAlchemy
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# create new instance
db = SQLAlchemy()

# Create class User
# Create class Condo
# Create class Like

class User(db.Model):
    __tablename__ = 'users'
    uid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)

class Like(db.Model):
    __tablename__ = 'likes'
    lid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    liker = db.Column(db.Integer, db.ForeignKey('users.uid'), nullable=False)
    liking = db.Column(db.Integer, db.ForeignKey('condos.cid'), nullable=False)

class Condo(db.Model):
    __tablename__ = 'condos'
    cid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    display_y = db.Column(db.Float, nullable=False)
    display_x = db.Column(db.Float, nullable=False)
    beds = db.Column(db.Integer, nullable=False)
    sqft = db.Column(db.Float, nullable=False)
    photo_url = db.Column(db.String(528), nullable=False)
    ppsf = db.Column(db.Float, nullable=False)
    baths = db.Column(db.Float, nullable=False)
    mlsnum = db.Column(db.Integer, nullable=False)
    list_price = db.Column(db.Float, nullable=False)
    remarks = db.Column(db.String(1024), nullable=False)
    predicted_price = db.Column(db.Float, nullable=False)
