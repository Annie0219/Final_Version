CREATE DATABASE team11_final_db;


DROP TABLE IF EXISTS users;
CREATE TABLE users (
    uid serial NOT NULL PRIMARY KEY,
    username TEXT NOT NULL,
    password TEXT NOT NULL
);


DROP TABLE IF EXISTS condos;
CREATE TABLE condos(
	cid serial PRIMARY KEY,
	display_y FLOAT not null,
	display_x FLOAT not null,
	beds INT not null,
	sqft FLOAT not null,
	photo_url TEXT not null,
	ppsf FLOAT not null,
	baths FLOAT not null,
	mlsnum INT not null,
	list_price FLOAT not null,
	remarks TEXT not null,
	predicted_price FLOAT not null
);


DROP TABLE IF EXISTS likes;
CREATE TABLE likes (
	    lid serial NOT NULL PRIMARY KEY,
    	liker serial NOT NULL, 
    	liking serial NOT NULL,
    	FOREIGN KEY (liker) REFERENCES users(uid),
    	FOREIGN KEY (liking) REFERENCES condos(cid)
);

INSERT INTO users (username, password) VALUES ('test', '12345')

INSERT INTO likes (liker, liking) VALUES ('1', '1');
INSERT INTO likes (liker, liking) VALUES ('1', '2');