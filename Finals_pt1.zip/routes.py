#!/usr/bin/env python3
# REFERENCES:
# Class lectures, labs and homeworks
# https://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-viii-followers
# https://docs.sqlalchemy.org/en/latest/core/metadata.html#accessing-tables-and-columns


from flask import Flask, flash, render_template, request, url_for, redirect, jsonify, session
from models import db, User, Condo, Like
from forms import LoginForm, SignupForm
from passlib.hash import sha256_crypt
from flask_heroku import Heroku
from sklearn.externals import joblib
import numpy as np
from utils import onehotCategorical

app = Flask(__name__)
app.secret_key = "team11_final"

# local postgresql or heroku postgresql
#heroku = Heroku(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql:///team11_final_db'

db.init_app(app)

model = joblib.load('gb.pkl')

# index route
@app.route('/')
@app.route('/index')
def index():
    
    if 'username' in session:
        session_user = User.query.filter_by(username=session['username']).first()

        return render_template('index.html', title='Home', session_username=session_user.username)
    else:
        return render_template('index.html', title='Home' )

# predict

@app.route('/predict', methods=['POST'])
def make_prediction():
    if request.method=='POST':

        # get request values

        #Already binary
        beds = request.form['beds']
        garage = request.form['garage']
        lotsize = request.form['lotsize']
        ppsf = request.form['ppsf']
        listmonth = request.form['listmonth']
        baths = request.form['baths']
        age = request.form['age']
        sqft = request.form['sqft']

        # one-hot encode categorical variables
        zip = request.form['zip']
        zip = zip.split('_', 1)[-1]
        zip = int(zip)

        zip_encode = onehotCategorical(zip, 708, zip=0)

        entered_li = []
        entered_li.extend(zip_encode)

        # beds insert at 4
        beds = float(beds)
        entered_li[4:4] = [beds]
        print (beds)

        # garage insert at 14
        garage = int(garage)
        entered_li[14:14] = [garage]

        # LOTSIZE insert at 114
        lotsize = float(lotsize)
        entered_li[114:114] = [lotsize]

        # PPSF insert at 270 
        ppsf = int(ppsf)
        entered_li[270:270] = [ppsf]

        # LISTMONTH insert at 337
        listmonth = int(listmonth)
        entered_li[337:337] = [listmonth]

        # BATHS insert at 349
        baths = float(baths)
        entered_li[349:349] = [baths]

        # AGE insert at 612
        age = int(age)
        entered_li[612:612] = [45]

        # SQFT insert at 691
        sqft = float (sqft)
        entered_li[691:691] = [sqft]

        # make prediction

        prediction = model.predict(np.array(entered_li).reshape(1, -1))

        label = str(np.squeeze(prediction.round(2)))
        print (label)
        #return render_template('index.html', label=label)

        if 'username' in session:
            session_user = User.query.filter_by(username=session['username']).first()

            return render_template('index.html', title='Home', session_username=session_user.username, label=label)
        else:
            return render_template('index.html', title='Home', label=label)

# signup route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if 'username' in session:
        return redirect(url_for('index'))

    form = SignupForm()
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        existing_user = User.query.filter_by(username=username).first()

        if existing_user:
            print("existing...")
            flash('The username already exists. Please pick another one.')
            return redirect(url_for('signup'))
        else:
            print("validating...")
            if form.validate_on_submit():
                user = User(username=username, password=sha256_crypt.hash(password))
                db.session.add(user)
                db.session.commit()
                flash('Congratulations, you are now a registered user!')
                return redirect(url_for('login'))

    return render_template('signup.html', title='Signup', form=form)

# login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'username' in session:
        return redirect(url_for('index'))

    form = LoginForm()
    print(request.method)
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()

        if user is None:
            flash('Invalid username')
            return redirect(url_for('login'))

        else:
            check_pw = sha256_crypt.verify(password, user.password)
            if not check_pw:
                flash('Invalid password')
                return redirect(url_for('login'))

            else:
                session['username'] = username
                return redirect(url_for('index'))
    else:
        return render_template('login.html', title='Login', form=form)

# logout route
@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return redirect(url_for('index'))

# info route
@app.route('/info/<mlsnum>', methods=['GET'])
def info(mlsnum):

    #get condo info
    condo_info = Condo.query.filter_by(mlsnum=mlsnum).first()

    print(condo_info)

    #find out if user has saved it (followed var boolean)
    if "username" in session:
        session_user = User.query.filter_by(username=session['username']).first()
        print("profile mlsnum: ", mlsnum)
        print("profile uid: ", session_user.uid)
        if Like.query.filter_by(liker=session_user.uid, liking=condo_info.cid).first():
            followed = True
        else:
            followed = False
        return render_template('info.html', condo=condo_info, session_username=session_user.username, followed=followed)

    return render_template('info.html', condo=condo_info)


# like route
@app.route('/like/<mlsnum>', methods=['POST'])
def like(mlsnum):
    session_user = User.query.filter_by(username=session['username']).first()
    condo_to_like = Condo.query.filter_by(mlsnum=mlsnum).first()

    new_follow = Like(liker=session_user.uid, liking=condo_to_like.cid)

    db.session.add(new_follow)
    db.session.commit()
    flash('Property added to favorites')
    return redirect(url_for('info', mlsnum=mlsnum))

# unlike route
@app.route('/unlike_prof/<mlsnum>', methods=['GET'])
def unlike_prof(mlsnum):
    session_user = User.query.filter_by(username=session['username']).first()
    condo_to_unlike = Condo.query.filter_by(mlsnum=mlsnum).first()

    delete_like = Like.query.filter_by(liker=session_user.uid, liking=condo_to_unlike.cid).first()
    db.session.delete(delete_like)
    db.session.commit()
    flash('Property removed from favorites')
    return redirect(url_for('profile', username=session_user))


@app.route('/unlike_info/<mlsnum>', methods=['POST'])
def unlike_info(mlsnum):
    session_user = User.query.filter_by(username=session['username']).first()
    condo_to_unlike = Condo.query.filter_by(mlsnum=mlsnum).first()

    delete_like = Like.query.filter_by(liker=session_user.uid, liking=condo_to_unlike.cid).first()
    db.session.delete(delete_like)
    db.session.commit()
    flash('Property removed from favorites')
    return redirect(url_for('info', mlsnum=mlsnum))


# profile route
@app.route('/profile/<username>', methods=['GET'])
def profile(username):
    if "username" in session:
        session_user = User.query.filter_by(username=session['username']).first()
        print("profile uid: ", session_user.username)
        print("profile uid: ", session_user.uid)

        profile_user_likes = Like.query.filter_by(liker=session_user.uid).all()
        print(profile_user_likes)

        # DO WE NEED SESSION UID???
        # uids_followed = [f.liking for f in profile_user_likes] + [session_user.uid]
        uids_followed = [f.liking for f in profile_user_likes]

        followed_condos = Condo.query.filter(Condo.cid.in_(uids_followed)).all()
        print("uids followed = ", uids_followed)
        return render_template('profile.html', likes=profile_user_likes, condos=followed_condos, session_username=session_user.username)

    flash('Please login to see favorites!')
    return redirect(url_for('index'))


# load_data route (for D3 vis)
@app.route('/load_data', methods=['GET'])
def load_data():
        condos_json = {'condos': []}
        condos = Condo.query.all()
        for condo in condos:
            condo_info = condo.__dict__
            del condo_info['_sa_instance_state']
            condos_json['condos'].append(condo_info)
        return jsonify(condos_json)



if __name__ == "__main__":
    app.run(debug=True)
