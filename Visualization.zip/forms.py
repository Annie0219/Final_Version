from flask_wtf import FlaskForm
from wtforms import StringField, FLoatField, SubmitField, SelectField, IntegerField
from wtforms,validators import DataRequired

class AddUserForm(FlaskForm):
	username = StringField ('Username', validators = [DataRequired()])
	first_name = StringField ('First Name', validators = [DataRequired()])
	last_name = StringField ('Last Name', validators = [DataRequired()])
	prog_lang = SelectField ('Programming Language', choices=[('cpp', 'C++'), ('py', 'Python',...)])
	experience_yr = FLoatField ("Years of Programming Experience", validators = [DataRequired()])
	age = IntegerField ("Age", validators=[DataRequired()])
	hwl_hrs = FLoatField ('Hours Spent on HW 1', validators=[DataRequired()])
	submit = SubmitField ('Add')
