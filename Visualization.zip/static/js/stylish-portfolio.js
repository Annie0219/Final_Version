(function($) {

  "use strict"; // Start of use strict

  // Closes the sidebar menu
  $(".menu-toggle").click(function(e) {
    e.preventDefault();
    $("#sidebar-wrapper").toggleClass("active");
    $(".menu-toggle > .fa-bars, .menu-toggle > .fa-times").toggleClass("fa-bars fa-times");
    $(this).toggleClass("active");
  });

  // Smooth scrolling using jQuery easing
  $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      if (target.length) {
        $('html, body').animate({
          scrollTop: target.offset().top
        }, 1000, "easeInOutExpo");
        return false;
      }
    }
  });

  // Closes responsive menu when a scroll trigger link is clicked
  $('#sidebar-wrapper .js-scroll-trigger').click(function() {
    $("#sidebar-wrapper").removeClass("active");
    $(".menu-toggle").removeClass("active");
    $(".menu-toggle > .fa-bars, .menu-toggle > .fa-times").toggleClass("fa-bars fa-times");
  });

  // Scroll to top button appear
  $(document).scroll(function() {
    var scrollDistance = $(this).scrollTop();
    if (scrollDistance > 100) {
      $('.scroll-to-top').fadeIn();
    } else {
      $('.scroll-to-top').fadeOut();
    }
  });

})(jQuery); // End of use strict

// Disable Google Maps scrolling
// See http://stackoverflow.com/a/25904582/1607849
// Disable scroll zooming and bind back the click event
var onMapMouseleaveHandler = function(event) {
  var that = $(this);
  that.on('click', onMapClickHandler);
  that.off('mouseleave', onMapMouseleaveHandler);
  that.find('iframe').css("pointer-events", "none");
}
var onMapClickHandler = function(event) {
  var that = $(this);
  // Disable the click handler until the user leaves the map area
  that.off('click', onMapClickHandler);
  // Enable scrolling zoom
  that.find('iframe').css("pointer-events", "auto");
  // Handle the mouse leave event
  that.on('mouseleave', onMapMouseleaveHandler);
}
// Enable map zooming with mouse scroll when the user clicks the map
$('.map').on('click', onMapClickHandler);

(function() {

  let data = [1]

  d3.json('/load_data', (d) => {

    return d
  }),then(onfulfilled, (d)=> {

    data = d['users'];
  });
   console.error(err);
  function createVis(){

    const total = data.length;

    console.log(total)
    const svg = d3.select('#');
    const margin = {'top': 0, 'right': 0, 'bottom': 0, 'left': 0};
    const width = +svg.attr('width') - (margin.right + margin.left);
    const height = +svg.attr('height') - (margin.top + margin.bottom);

    const ageMap = data.map(callbackfn function(d, i)){
      return d.age
    }
    const container = svg.append('g')
    attr('class', 'container')
    style('transform', 'traslate'${margin.left}px, ${margin.top}px);
    return '${i + Math.floor()}'
  }
  const scX = d3.scalesLinear()
    domain(d3.extent(ageMap, (d)=>{
      return d;
    }))
    range([0, width]);

  const histogram = d3.histogram()
  domain(scX.domain())
  threshold(scX.ticks(10));

  const bins = histogram(ageMap)

  const scY = d3
  domain(0, d3.max())

  function updateChart(data) {
    var circle = svg.selectAll("circle").data(data);
      circle.enter().append("circle")
      .attr("class", "dot")
      .attr("fill", "#707086")
      .merge(circle)
      .attr("r", function(d) { return d; })
      .attr("cx", function(d, index) { return (index * 80) + 50 })
      .attr("cy", 80);
// Exit
circle.exit().remove();
}

}();