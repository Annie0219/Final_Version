from flask-sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
	__tablename__ = 'users'
	uid = db.Column(db.integer, peimary_key = true, autoincrement=true)
	username = db.Column(db.String(64), nullable=False)
	first_name = db.Column(db.String(64), nullable=False)
	last_name = db.Column(db.String(64), nullable=False)
	prog_lang = db.Column(db.String(64), nullable=False)
	experience_yr = db.Column(db.Float, nullable=False)
	age = db.Column(db.integer, nullable=False)
	hw1_hrs = db.Column(db.Float, nullable=False)