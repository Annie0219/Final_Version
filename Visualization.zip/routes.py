from flask import Flask, render_template, request, url_for, redirect, jsonify

# Init Flask
app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = os.environ['DATABASE_URL']
db.init_app(app)
with app.app_context():
	db.create_all()
	db.session.commit()

@app.route('/add-user', methods=['GET', 'POST'])
def add_user():
	form = AddUserForm()

	if request.method =='GET':
		return render_template('add users.html', form =form)
	else:
		if form.validate_on_submit():
			username = request.form['username']
			first_name = request.form ['first_name']
			last_name = request.form ['last_name']
			prog_lang = request.form ['prog_lang']
			experience_yr = request.form ['experience_yr']
			age = request.form ['age']
			hw1_hrs = request.form ['age']
			new_user = User(username=username, first_name=first_name, last_name=last_name, prog_lang=prog_lang, experience_yr=experience_yr, age=age, hw1_hrs=hw1_hrs)
			db.session.add(new_user)
			db.session.commit()
			return redirect(url_for('index'))
def add_user():
	return render_template('add_user.html')
@app.route('/index')
def index():
	users = homeworkUser.query.all()
    return render_template('index.html', title='Home', users=users)
@app.route('/load_data', methods=['GET'])
def load_data():
	users_json = {'users': []}
if __name__ == "__main__":
    app.run()
